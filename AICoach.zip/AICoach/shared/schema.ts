import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id).notNull(),
  questionnaireData: jsonb("questionnaire_data"),
  currentState: jsonb("current_state"),
  potentialState: jsonb("potential_state"),
  recommendations: jsonb("recommendations"),
  dailyPlan: jsonb("daily_plan"),
  progress: jsonb("progress"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
});

export const insertSessionSchema = createInsertSchema(sessions).pick({
  userId: true,
  questionnaireData: true,
  currentState: true,
  potentialState: true,
  recommendations: true,
  dailyPlan: true,
  progress: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

// Type definitions for questionnaire and analysis data
export interface QuestionnaireAnswer {
  questionId: string;
  question: string;
  answer: string | string[];
  type: 'multiple_choice' | 'text' | 'checkbox' | 'scale';
}

export interface PersonalityAnalysis {
  productivity: number;
  fitness: number;
  learning: number;
  wellness: number;
  focus: number;
  energy: number;
}

export interface AIRecommendation {
  category: 'daily_habits' | 'fitness' | 'learning' | 'wellness';
  title: string;
  description: string;
  frequency: string;
  priority: 'high' | 'medium' | 'low';
  estimatedImpact: number;
}

export interface DailyTask {
  id: string;
  title: string;
  description: string;
  category: string;
  scheduledTime?: string;
  completed: boolean;
  priority: 'high' | 'medium' | 'low';
}
