# Personal Development Coaching Application

## Overview

This is a full-stack personal development coaching application that uses AI-powered questionnaires and analysis to provide personalized recommendations and daily task planning. The application combines a React frontend with a Node.js/Express backend, utilizing OpenAI's GPT models for intelligent content generation and PostgreSQL for data persistence.

The system guides users through an onboarding questionnaire, analyzes their responses to understand their current state and potential, then generates personalized recommendations and daily action plans to help them achieve their goals.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and dark theme
- **Animations**: Framer Motion for smooth page transitions and micro-interactions
- **State Management**: TanStack Query for server state management and caching
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with structured error handling
- **Middleware**: Custom logging middleware for API request tracking
- **Development**: Vite integration for hot module replacement in development

### Data Storage Solutions
- **Database**: PostgreSQL with Neon Database serverless hosting
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema evolution
- **Session Storage**: In-memory storage with interface for database migration
- **Data Types**: JSONB columns for flexible questionnaire data, analysis results, and recommendations

### Authentication and Authorization
- **User Management**: Simple username-based user creation and lookup
- **Session Management**: User ID stored in localStorage for client-side session tracking
- **Data Isolation**: All data operations scoped by user ID to ensure privacy

### External Service Integrations
- **AI Processing**: OpenAI GPT-5 for questionnaire generation, analysis, and recommendations
- **Font Loading**: Google Fonts integration for typography (Inter, DM Sans, Fira Code, Geist Mono, Architects Daughter)
- **Development Tools**: Replit-specific plugins for enhanced development experience

### Key Architectural Decisions

**Questionnaire System**: Dynamic question generation using AI allows for personalized onboarding experiences. The system can generate follow-up questions based on previous answers, creating an adaptive interview process.

**Analysis Engine**: Dual-state personality analysis (current vs potential) provides users with clear improvement targets. The AI analyzes questionnaire responses to identify strengths, weaknesses, and growth opportunities.

**Recommendation System**: Multi-category recommendations (productivity, fitness, learning, wellness) with priority levels ensure comprehensive personal development coverage.

**Data Flexibility**: JSONB storage allows for evolving data structures without schema migrations, supporting the dynamic nature of AI-generated content.

**Progressive Enhancement**: The application works as a single-page application with smooth transitions while maintaining RESTful API principles for potential mobile app integration.

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL serverless driver for database connectivity
- **drizzle-orm**: Type-safe ORM for database operations
- **drizzle-zod**: Schema validation integration
- **openai**: Official OpenAI API client for GPT model access

### Frontend Dependencies
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight React router
- **framer-motion**: Animation library for smooth user interactions
- **@radix-ui/***: Comprehensive set of accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **zod**: TypeScript-first schema validation

### Development Dependencies
- **vite**: Fast build tool and development server
- **tsx**: TypeScript execution for Node.js
- **esbuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-***: Replit-specific development enhancements

### Database Configuration
- **Environment**: DATABASE_URL required for PostgreSQL connection
- **Migrations**: Stored in `./migrations` directory
- **Schema**: Centralized in `./shared/schema.ts` for type sharing