import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { Home, ClipboardList, BarChart3, Lightbulb, Gauge } from "lucide-react";

interface NavItem {
  icon: React.ReactNode;
  path: string;
  label: string;
}

const navItems: NavItem[] = [
  { icon: <Home size={20} />, path: "/", label: "Home" },
  { icon: <ClipboardList size={20} />, path: "/questionnaire", label: "Questions" },
  { icon: <BarChart3 size={20} />, path: "/charts", label: "Analysis" },
  { icon: <Lightbulb size={20} />, path: "/recommendations", label: "Recommendations" },
  { icon: <Gauge size={20} />, path: "/dashboard", label: "Dashboard" },
];

export function Navigation() {
  const [location, setLocation] = useLocation();

  return (
    <motion.div
      className="fixed bottom-0 left-0 right-0 p-4 z-50"
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="max-w-md mx-auto glass-card rounded-2xl p-4">
        <div className="flex justify-around">
          {navItems.map((item) => {
            const isActive = location === item.path;
            return (
              <motion.button
                key={item.path}
                className={`p-3 rounded-lg transition-all relative ${
                  isActive
                    ? "text-primary bg-primary/10"
                    : "text-muted-foreground hover:text-primary hover:bg-primary/10"
                }`}
                onClick={() => setLocation(item.path)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                data-testid={`nav-${item.label.toLowerCase()}`}
              >
                {item.icon}
                {isActive && (
                  <motion.div
                    className="absolute -top-1 -right-1 w-2 h-2 bg-primary rounded-full"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.2 }}
                  />
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
    </motion.div>
  );
}
