import { apiRequest } from "./queryClient";
import { type User, type QuestionnaireAnswer, type PersonalityAnalysis, type AIRecommendation, type DailyTask } from "@shared/schema";

export interface GeneratedQuestion {
  id: string;
  question: string;
  type: 'multiple_choice' | 'text' | 'checkbox' | 'scale';
  options?: string[];
  category: 'productivity' | 'fitness' | 'learning' | 'wellness' | 'general';
}

// User API
export async function createUser(username: string): Promise<User> {
  const res = await apiRequest("POST", "/api/users", { username });
  return res.json();
}

export async function getUser(username: string): Promise<User> {
  const res = await apiRequest("GET", `/api/users/${username}`);
  return res.json();
}

// Questionnaire API
export async function getInitialQuestions(userId: string): Promise<GeneratedQuestion[]> {
  const res = await apiRequest("GET", `/api/questionnaire/initial/${userId}`);
  const data = await res.json();
  return data.questions;
}

export async function submitAnswer(userId: string, answer: QuestionnaireAnswer): Promise<{ success: boolean; followUpQuestion?: GeneratedQuestion }> {
  const res = await apiRequest("POST", `/api/questionnaire/answer/${userId}`, answer);
  return res.json();
}

export async function completeQuestionnaire(userId: string): Promise<{
  success: boolean;
  analysis: { currentState: PersonalityAnalysis; potentialState: PersonalityAnalysis };
  recommendations: AIRecommendation[];
  dailyPlan: DailyTask[];
}> {
  const res = await apiRequest("POST", `/api/questionnaire/complete/${userId}`);
  return res.json();
}

// Analysis API
export async function getAnalysis(userId: string): Promise<{ currentState: PersonalityAnalysis; potentialState: PersonalityAnalysis }> {
  const res = await apiRequest("GET", `/api/analysis/${userId}`);
  return res.json();
}

// Recommendations API
export async function getRecommendations(userId: string): Promise<AIRecommendation[]> {
  const res = await apiRequest("GET", `/api/recommendations/${userId}`);
  const data = await res.json();
  return data.recommendations;
}

// Daily Plan API
export async function getDailyPlan(userId: string): Promise<DailyTask[]> {
  const res = await apiRequest("GET", `/api/daily-plan/${userId}`);
  const data = await res.json();
  return data.tasks;
}

export async function updateTaskCompletion(userId: string, taskId: string, completed: boolean): Promise<{ success: boolean }> {
  const res = await apiRequest("PATCH", `/api/daily-plan/${userId}/${taskId}`, { completed });
  return res.json();
}

// AI Insights API
export async function getPersonalizedInsight(userId: string): Promise<string> {
  const res = await apiRequest("GET", `/api/insights/${userId}`);
  const data = await res.json();
  return data.insight;
}
