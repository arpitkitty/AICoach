import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight, Brain } from "lucide-react";
import { Loading, FullPageLoading } from "@/components/ui/loading";
import { useMutation, useQuery } from "@tanstack/react-query";
import { getInitialQuestions, submitAnswer, completeQuestionnaire } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { GeneratedQuestion } from "@/lib/api";
import type { QuestionnaireAnswer } from "@shared/schema";

export default function Questionnaire() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [questions, setQuestions] = useState<GeneratedQuestion[]>([]);
  const [answers, setAnswers] = useState<QuestionnaireAnswer[]>([]);
  const [currentAnswer, setCurrentAnswer] = useState<string | string[]>("");
  const [isCompleting, setIsCompleting] = useState(false);

  const userId = localStorage.getItem("userId");
  const username = localStorage.getItem("username");

  const { data: initialQuestions, isLoading, error } = useQuery({
    queryKey: ["/api/questionnaire/initial", userId],
    queryFn: () => getInitialQuestions(userId!),
    enabled: !!userId,
  });

  const submitAnswerMutation = useMutation({
    mutationFn: (answer: QuestionnaireAnswer) => submitAnswer(userId!, answer),
    onSuccess: (data) => {
      if (data.followUpQuestion) {
        setQuestions(prev => [...prev, data.followUpQuestion!]);
      }
      setCurrentAnswer("");
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1);
      } else {
        handleComplete();
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit answer. Please try again.",
        variant: "destructive",
      });
    },
  });

  const completeQuestionnaireMutation = useMutation({
    mutationFn: () => completeQuestionnaire(userId!),
    onSuccess: () => {
      setLocation("/charts");
      toast({
        title: "Analysis Complete!",
        description: "Your personalized insights are ready.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to complete analysis. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!userId) {
      setLocation("/");
      return;
    }
    if (initialQuestions) {
      setQuestions(initialQuestions);
    }
  }, [userId, initialQuestions, setLocation]);

  const handleComplete = async () => {
    setIsCompleting(true);
    completeQuestionnaireMutation.mutate();
  };

  const handleNext = () => {
    const currentQuestion = questions[currentQuestionIndex];
    if (!currentAnswer || (Array.isArray(currentAnswer) && currentAnswer.length === 0)) {
      toast({
        title: "Answer required",
        description: "Please provide an answer before continuing.",
        variant: "destructive",
      });
      return;
    }

    const answerData: QuestionnaireAnswer = {
      questionId: currentQuestion.id,
      question: currentQuestion.question,
      answer: currentAnswer,
      type: currentQuestion.type,
    };

    setAnswers(prev => [...prev, answerData]);
    submitAnswerMutation.mutate(answerData);
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
      const previousAnswer = answers[currentQuestionIndex - 1];
      if (previousAnswer) {
        setCurrentAnswer(previousAnswer.answer);
      }
    }
  };

  const handleAnswerChange = (value: string | string[]) => {
    setCurrentAnswer(value);
  };

  if (!userId) {
    return null;
  }

  if (isLoading) {
    return <FullPageLoading message="Generating your personalized questions..." />;
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="glass-card max-w-md mx-auto">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Brain className="w-8 h-8 text-red-400" />
            </div>
            <h3 className="text-xl font-semibold mb-4 text-red-400">AI Service Unavailable</h3>
            <p className="text-muted-foreground mb-6">
              The AI questionnaire service is currently unavailable. This might be due to:
              <br />• OpenAI API quota exceeded
              <br />• Temporary service outage
              <br />• Network connectivity issues
            </p>
            <div className="space-y-3">
              <Button 
                onClick={() => window.location.reload()} 
                className="w-full glow-button"
                data-testid="button-retry"
              >
                Try Again
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setLocation("/")} 
                className="w-full"
                data-testid="button-go-home"
              >
                Go Home
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (isCompleting || completeQuestionnaireMutation.isPending) {
    return <FullPageLoading message="Analyzing your responses with AI..." />;
  }

  if (questions.length === 0) {
    return <FullPageLoading message="Preparing your questionnaire..." />;
  }

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / Math.max(questions.length, 7)) * 100;

  const renderQuestionInput = () => {
    switch (currentQuestion.type) {
      case 'multiple_choice':
        return (
          <div className="space-y-3">
            {currentQuestion.options?.map((option, index) => (
              <motion.label
                key={index}
                className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <input
                  type="radio"
                  name="answer"
                  value={option}
                  checked={currentAnswer === option}
                  onChange={(e) => handleAnswerChange(e.target.value)}
                  className="text-primary focus:ring-primary"
                  data-testid={`radio-option-${index}`}
                />
                <span>{option}</span>
              </motion.label>
            ))}
          </div>
        );

      case 'checkbox':
        return (
          <div className="space-y-3">
            {currentQuestion.options?.map((option, index) => (
              <motion.label
                key={index}
                className="flex items-center space-x-3 p-3 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Checkbox
                  checked={Array.isArray(currentAnswer) && currentAnswer.includes(option)}
                  onCheckedChange={(checked) => {
                    const newAnswer = Array.isArray(currentAnswer) ? [...currentAnswer] : [];
                    if (checked) {
                      newAnswer.push(option);
                    } else {
                      const index = newAnswer.indexOf(option);
                      if (index > -1) newAnswer.splice(index, 1);
                    }
                    handleAnswerChange(newAnswer);
                  }}
                  data-testid={`checkbox-option-${index}`}
                />
                <span>{option}</span>
              </motion.label>
            ))}
          </div>
        );

      case 'scale':
        return (
          <div className="space-y-4">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>Strongly Disagree</span>
              <span>Strongly Agree</span>
            </div>
            <div className="flex justify-between">
              {[1, 2, 3, 4, 5].map((value) => (
                <motion.label
                  key={value}
                  className="flex flex-col items-center space-y-2 cursor-pointer"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                >
                  <input
                    type="radio"
                    name="scale"
                    value={value.toString()}
                    checked={currentAnswer === value.toString()}
                    onChange={(e) => handleAnswerChange(e.target.value)}
                    className="text-primary focus:ring-primary"
                    data-testid={`scale-${value}`}
                  />
                  <span className="text-sm">{value}</span>
                </motion.label>
              ))}
            </div>
          </div>
        );

      case 'text':
        return (
          <Textarea
            placeholder="Share your thoughts..."
            value={currentAnswer as string}
            onChange={(e) => handleAnswerChange(e.target.value)}
            className="w-full min-h-[100px] resize-none"
            data-testid="textarea-answer"
          />
        );

      default:
        return (
          <Input
            type="text"
            placeholder="Your answer..."
            value={currentAnswer as string}
            onChange={(e) => handleAnswerChange(e.target.value)}
            className="w-full"
            data-testid="input-answer"
          />
        );
    }
  };

  return (
    <div className="min-h-screen p-4 pb-24">
      <div className="container mx-auto max-w-4xl">
        {/* Header */}
        <motion.div
          className="mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">
              Getting to know you, <span className="gradient-text">{username}</span>
            </h2>
            <span className="text-muted-foreground" data-testid="progress-indicator">
              {currentQuestionIndex + 1} of {Math.max(questions.length, 7)}
            </span>
          </div>
          <Progress value={progress} className="w-full" />
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Question */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Card className="glass-card">
              <CardContent className="p-8">
                <h3 className="text-xl font-semibold mb-6 flex items-center">
                  <Brain className="text-primary mr-3" size={24} />
                  <span data-testid="current-question">{currentQuestion.question}</span>
                </h3>

                {renderQuestionInput()}
              </CardContent>
            </Card>

            {/* Navigation */}
            <div className="flex justify-between">
              <Button
                variant="ghost"
                onClick={handlePrevious}
                disabled={currentQuestionIndex === 0 || submitAnswerMutation.isPending}
                data-testid="button-previous"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>

              <Button
                className="glow-button"
                onClick={handleNext}
                disabled={submitAnswerMutation.isPending}
                data-testid="button-next"
              >
                {submitAnswerMutation.isPending ? (
                  <Loading message="" />
                ) : (
                  <>
                    {currentQuestionIndex === questions.length - 1 ? "Complete" : "Next Question"}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </motion.div>

          {/* Side Content */}
          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            {/* Inspiration Image */}
            <Card className="glass-card overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300"
                alt="Modern productive workspace with fitness elements"
                className="w-full h-48 object-cover"
              />
              <CardContent className="p-6">
                <h4 className="font-semibold mb-2">AI-Powered Insights</h4>
                <p className="text-muted-foreground text-sm">
                  Based on your responses, we're building a personalized roadmap for your success.
                </p>
              </CardContent>
            </Card>

            {/* Progress Card */}
            <Card className="glass-card">
              <CardContent className="p-6">
                <h4 className="font-semibold mb-4 flex items-center">
                  <Brain className="text-secondary mr-2" size={20} />
                  Your Progress
                </h4>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Profile Completion</span>
                    <span data-testid="completion-percentage">{Math.round(progress)}%</span>
                  </div>
                  <Progress value={progress} />
                  <p className="text-sm text-muted-foreground">
                    {answers.length} answers collected
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
