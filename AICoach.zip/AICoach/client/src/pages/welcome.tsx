import { useState } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Rocket } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { createUser } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export default function Welcome() {
  const [username, setUsername] = useState("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const createUserMutation = useMutation({
    mutationFn: createUser,
    onSuccess: (user) => {
      localStorage.setItem("userId", user.id);
      localStorage.setItem("username", user.username);
      setLocation("/questionnaire");
      toast({
        title: "Welcome aboard!",
        description: `Great to meet you, ${user.username}!`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create user. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      toast({
        title: "Name required",
        description: "Please enter your name to continue.",
        variant: "destructive",
      });
      return;
    }
    createUserMutation.mutate(username.trim());
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="container mx-auto max-w-4xl">
        <motion.div
          className="text-center space-y-8"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Hero Image */}
          <motion.div
            className="mx-auto w-32 h-32 rounded-full overflow-hidden mb-8 ring-4 ring-primary/30"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <img
              src="https://images.unsplash.com/photo-1553484771-371a605b060b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
              alt="AI Personal Development Dashboard"
              className="w-full h-full object-cover"
            />
          </motion.div>

          {/* Title */}
          <motion.h1
            className="text-5xl md:text-7xl font-bold gradient-text mb-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Level Up
          </motion.h1>

          {/* Subtitle */}
          <motion.p
            className="text-xl md:text-2xl text-muted-foreground mb-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            AI-powered personal development tailored just for you
          </motion.p>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <Card className="glass-card max-w-md mx-auto">
              <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <Label className="text-sm font-medium text-muted-foreground mb-2 block">
                      What should we call you?
                    </Label>
                    <Input
                      type="text"
                      placeholder="Enter your name"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full px-4 py-3 bg-input border border-border rounded-lg focus:ring-2 focus:ring-ring focus:border-transparent text-foreground placeholder-muted-foreground transition-all"
                      data-testid="input-username"
                      disabled={createUserMutation.isPending}
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full glow-button text-primary-foreground font-medium py-3 px-6 rounded-lg transition-all duration-300"
                    disabled={createUserMutation.isPending || !username.trim()}
                    data-testid="button-start-journey"
                  >
                    <Rocket className="mr-2 h-4 w-4" />
                    {createUserMutation.isPending ? "Starting..." : "Start Your Journey"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
