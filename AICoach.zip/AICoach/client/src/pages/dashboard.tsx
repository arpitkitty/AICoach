import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { LineChart, Line, ResponsiveContainer } from "recharts";
import { CheckCircle, Clock, Dumbbell, Book, Flame, Lightbulb, TrendingUp } from "lucide-react";
import { FullPageLoading } from "@/components/ui/loading";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getDailyPlan, updateTaskCompletion, getPersonalizedInsight } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { DailyTask } from "@shared/schema";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const userId = localStorage.getItem("userId");
  const username = localStorage.getItem("username");

  const { data: dailyPlan, isLoading: planLoading } = useQuery({
    queryKey: ["/api/daily-plan", userId],
    queryFn: () => getDailyPlan(userId!),
    enabled: !!userId,
  });

  const { data: personalizedInsight } = useQuery({
    queryKey: ["/api/insights", userId],
    queryFn: () => getPersonalizedInsight(userId!),
    enabled: !!userId,
  });

  const updateTaskMutation = useMutation({
    mutationFn: ({ taskId, completed }: { taskId: string; completed: boolean }) =>
      updateTaskCompletion(userId!, taskId, completed),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/daily-plan", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/insights", userId] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update task. Please try again.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (!userId) {
      setLocation("/");
      return;
    }
  }, [userId, setLocation]);

  if (!userId) {
    return null;
  }

  if (planLoading) {
    return <FullPageLoading message="Loading your personalized dashboard..." />;
  }

  if (!dailyPlan || dailyPlan.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="glass-card max-w-md mx-auto">
          <CardContent className="p-8 text-center">
            <Lightbulb className="w-16 h-16 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-4">No Plan Available</h3>
            <p className="text-muted-foreground mb-6">
              Complete your questionnaire and view recommendations to get your personalized daily plan.
            </p>
            <Button onClick={() => setLocation("/questionnaire")} className="glow-button">
              Get Started
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const completedTasks = dailyPlan.filter(task => task.completed);
  const totalTasks = dailyPlan.length;
  const completionRate = Math.round((completedTasks.length / totalTasks) * 100);

  // Mock weekly data for the chart
  const weeklyData = [
    { day: 'Mon', score: 7.2 },
    { day: 'Tue', score: 8.1 },
    { day: 'Wed', score: 6.8 },
    { day: 'Thu', score: 8.5 },
    { day: 'Fri', score: 7.9 },
    { day: 'Sat', score: 6.4 },
    { day: 'Sun', score: 7.7 },
  ];

  const handleTaskToggle = (taskId: string, completed: boolean) => {
    updateTaskMutation.mutate({ taskId, completed });
  };

  const dayStreak = 7; // This would come from backend calculation
  const focusedTime = "5.2h";
  const exerciseTime = "45min";
  const learningTime = "30min";

  return (
    <div className="min-h-screen p-4 pb-24">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <motion.div
          className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div>
            <h2 className="text-3xl font-bold gradient-text mb-2">
              Welcome back, <span data-testid="user-name">{username}</span>!
            </h2>
            <p className="text-muted-foreground">Here's your progress for today</p>
          </div>
          <div className="flex items-center space-x-4 mt-4 sm:mt-0">
            <div className="text-center">
              <div className="text-2xl font-bold text-primary" data-testid="day-streak">{dayStreak}</div>
              <div className="text-xs text-muted-foreground">Day Streak</div>
            </div>
            <div className="w-12 h-12 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center">
              <Flame className="text-white" size={20} />
            </div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          className="grid md:grid-cols-4 gap-6 mb-8"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Card className="glass-card text-center">
            <CardContent className="p-6">
              <div className="w-16 h-16 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="text-white text-xl" />
              </div>
              <div className="text-2xl font-bold gradient-text mb-1" data-testid="tasks-completed">
                {completedTasks.length}/{totalTasks}
              </div>
              <div className="text-sm text-muted-foreground">Tasks Completed</div>
            </CardContent>
          </Card>

          <Card className="glass-card text-center">
            <CardContent className="p-6">
              <div className="w-16 h-16 bg-gradient-to-r from-secondary to-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-white text-xl" />
              </div>
              <div className="text-2xl font-bold gradient-text mb-1" data-testid="focused-time">{focusedTime}</div>
              <div className="text-sm text-muted-foreground">Focused Time</div>
            </CardContent>
          </Card>

          <Card className="glass-card text-center">
            <CardContent className="p-6">
              <div className="w-16 h-16 bg-gradient-to-r from-accent to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <Dumbbell className="text-white text-xl" />
              </div>
              <div className="text-2xl font-bold gradient-text mb-1" data-testid="exercise-time">{exerciseTime}</div>
              <div className="text-sm text-muted-foreground">Exercise</div>
            </CardContent>
          </Card>

          <Card className="glass-card text-center">
            <CardContent className="p-6">
              <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <Book className="text-white text-xl" />
              </div>
              <div className="text-2xl font-bold gradient-text mb-1" data-testid="learning-time">{learningTime}</div>
              <div className="text-sm text-muted-foreground">Learning</div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          <motion.div
            className="lg:col-span-2 space-y-6"
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            {/* Today's Focus */}
            <Card className="glass-card">
              <CardContent className="p-8">
                <h3 className="text-xl font-semibold mb-6 flex items-center">
                  <CheckCircle className="text-primary mr-3" size={24} />
                  Today's Focus
                </h3>
                <div className="space-y-4">
                  {dailyPlan.map((task, index) => (
                    <motion.div
                      key={task.id}
                      className={`flex items-center space-x-4 p-4 rounded-lg transition-all ${
                        task.completed
                          ? "bg-muted/30 opacity-60"
                          : task.priority === 'high'
                          ? "bg-primary/10 border border-primary/20"
                          : "bg-muted/30"
                      }`}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <Checkbox
                        checked={task.completed}
                        onCheckedChange={(checked) => handleTaskToggle(task.id, !!checked)}
                        disabled={updateTaskMutation.isPending}
                        data-testid={`task-${index}`}
                      />
                      <div className="flex-1">
                        <p className={`font-medium ${task.completed ? 'line-through' : ''}`}>
                          {task.title}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {task.completed 
                            ? "✓ Completed" 
                            : task.scheduledTime 
                            ? `⏰ ${task.scheduledTime}` 
                            : `📅 ${task.priority} priority`
                          }
                        </p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            className="space-y-6"
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            {/* Progress Chart */}
            <Card className="glass-card">
              <CardContent className="p-6">
                <h4 className="font-semibold mb-4 flex items-center">
                  <TrendingUp className="text-secondary mr-2" size={20} />
                  Weekly Progress
                </h4>
                <ResponsiveContainer width="100%" height={200}>
                  <LineChart data={weeklyData}>
                    <Line
                      type="monotone"
                      dataKey="score"
                      stroke="hsl(197, 71%, 50%)"
                      strokeWidth={3}
                      dot={{ fill: "hsl(197, 71%, 50%)", strokeWidth: 2, r: 4 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
                <div className="text-center mt-4">
                  <div className="text-lg font-semibold gradient-text" data-testid="completion-rate">
                    {completionRate}% Complete
                  </div>
                  <div className="text-sm text-muted-foreground">Today's tasks</div>
                </div>
              </CardContent>
            </Card>

            {/* AI Suggestion */}
            <Card className="glass-card bg-gradient-to-br from-primary/5 to-accent/5 border border-primary/20">
              <CardContent className="p-6">
                <h4 className="font-semibold mb-3 flex items-center">
                  <Lightbulb className="text-primary mr-2" size={20} />
                  AI Suggestion
                </h4>
                <p className="text-sm text-muted-foreground mb-4" data-testid="ai-suggestion">
                  {personalizedInsight || "Keep up the great work! You're making excellent progress on your personal development journey."}
                </p>
                <Button
                  variant="ghost"
                  className="text-primary text-sm font-medium hover:text-primary/80 transition-colors p-0"
                  onClick={() => {
                    toast({
                      title: "Suggestion Applied",
                      description: "This insight has been noted for your improvement.",
                    });
                  }}
                  data-testid="button-apply-suggestion"
                >
                  Apply suggestion →
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
