import { useEffect } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { BarChart3, Rocket, TrendingUp } from "lucide-react";
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, ResponsiveContainer } from "recharts";
import { Loading, FullPageLoading } from "@/components/ui/loading";
import { useQuery } from "@tanstack/react-query";
import { getAnalysis } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export default function Charts() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const userId = localStorage.getItem("userId");

  const { data: analysis, isLoading, error } = useQuery({
    queryKey: ["/api/analysis", userId],
    queryFn: () => getAnalysis(userId!),
    enabled: !!userId,
  });

  useEffect(() => {
    if (!userId) {
      setLocation("/");
      return;
    }
    if (error) {
      toast({
        title: "Error",
        description: "Failed to load analysis. Please try again.",
        variant: "destructive",
      });
    }
  }, [userId, error, setLocation, toast]);

  if (!userId) {
    return null;
  }

  if (isLoading) {
    return <FullPageLoading message="Loading your personalized analysis..." />;
  }

  if (!analysis) {
    return <FullPageLoading message="Analysis not available. Please complete the questionnaire first." />;
  }

  const currentData = [
    { category: 'Productivity', current: analysis.currentState.productivity, potential: analysis.potentialState.productivity },
    { category: 'Fitness', current: analysis.currentState.fitness, potential: analysis.potentialState.fitness },
    { category: 'Learning', current: analysis.currentState.learning, potential: analysis.potentialState.learning },
    { category: 'Wellness', current: analysis.currentState.wellness, potential: analysis.potentialState.wellness },
    { category: 'Focus', current: analysis.currentState.focus, potential: analysis.potentialState.focus },
    { category: 'Energy', current: analysis.currentState.energy, potential: analysis.potentialState.energy },
  ];

  const improvements = currentData.map(item => ({
    category: item.category,
    improvement: item.potential - item.current
  }));

  const averageImprovement = improvements.reduce((sum, item) => sum + item.improvement, 0) / improvements.length;

  return (
    <div className="min-h-screen p-4 pb-24">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl font-bold gradient-text mb-4">Your Present vs Potential</h2>
          <p className="text-xl text-muted-foreground">
            AI analysis of your current status and predicted improvements
          </p>
        </motion.div>

        {/* Charts Grid */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Current State Chart */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Card className="glass-card">
              <CardContent className="p-8">
                <h3 className="text-2xl font-semibold mb-6 flex items-center">
                  <BarChart3 className="text-accent mr-3" size={24} />
                  Current State
                </h3>
                <div className="chart-container">
                  <ResponsiveContainer width="100%" height={300}>
                    <RadarChart data={currentData}>
                      <PolarGrid stroke="rgba(255,255,255,0.1)" />
                      <PolarAngleAxis 
                        dataKey="category" 
                        tick={{ fill: 'rgba(255,255,255,0.7)', fontSize: 12 }}
                      />
                      <Radar
                        name="Current"
                        dataKey="current"
                        stroke="hsl(330, 75%, 60%)"
                        fill="hsl(330, 75%, 60%)"
                        fillOpacity={0.1}
                        strokeWidth={2}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-6 space-y-3">
                  {currentData.map((item, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                      <span className="flex items-center">
                        <div className="w-3 h-3 bg-accent rounded-full mr-3"></div>
                        {item.category}
                      </span>
                      <span className="font-semibold" data-testid={`current-${item.category.toLowerCase()}`}>
                        {item.current.toFixed(1)}/10
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Potential State Chart */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <Card className="glass-card">
              <CardContent className="p-8">
                <h3 className="text-2xl font-semibold mb-6 flex items-center">
                  <Rocket className="text-primary mr-3" size={24} />
                  AI-Predicted Potential
                </h3>
                <div className="chart-container">
                  <ResponsiveContainer width="100%" height={300}>
                    <RadarChart data={currentData}>
                      <PolarGrid stroke="rgba(255,255,255,0.1)" />
                      <PolarAngleAxis 
                        dataKey="category" 
                        tick={{ fill: 'rgba(255,255,255,0.7)', fontSize: 12 }}
                      />
                      <Radar
                        name="Potential"
                        dataKey="potential"
                        stroke="hsl(262, 80%, 65%)"
                        fill="hsl(262, 80%, 65%)"
                        fillOpacity={0.1}
                        strokeWidth={2}
                      />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-6 space-y-3">
                  {currentData.map((item, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-muted/30 rounded-lg">
                      <span className="flex items-center">
                        <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
                        {item.category}
                      </span>
                      <span className="font-semibold gradient-text" data-testid={`potential-${item.category.toLowerCase()}`}>
                        {item.potential.toFixed(1)}/10
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Improvement Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <Card className="glass-card mb-8">
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold mb-6 text-center">Projected Improvements</h3>
              <div className="grid md:grid-cols-3 gap-6">
                {improvements.slice(0, 3).map((item, index) => (
                  <motion.div
                    key={index}
                    className="text-center"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.8 + index * 0.1 }}
                  >
                    <div className="w-20 h-20 bg-gradient-to-r from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-4">
                      <span className="text-2xl font-bold text-primary-foreground">
                        +{item.improvement.toFixed(1)}
                      </span>
                    </div>
                    <h4 className="font-semibold mb-2">{item.category} Boost</h4>
                    <p className="text-muted-foreground text-sm">
                      {item.improvement > 2 ? "Significant" : item.improvement > 1 ? "Moderate" : "Gradual"} improvement potential
                    </p>
                  </motion.div>
                ))}
              </div>
              
              <motion.div
                className="text-center mt-8 p-6 bg-gradient-to-r from-primary/10 to-accent/10 rounded-xl border border-primary/20"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 1.2 }}
              >
                <TrendingUp className="w-12 h-12 text-primary mx-auto mb-4" />
                <h4 className="text-xl font-semibold mb-2">Average Improvement</h4>
                <p className="text-3xl font-bold gradient-text mb-2" data-testid="average-improvement">
                  +{averageImprovement.toFixed(1)} points
                </p>
                <p className="text-muted-foreground">
                  Across all areas with AI-guided optimization
                </p>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Action Button */}
        <motion.div
          className="text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1.4 }}
        >
          <Button
            className="glow-button text-primary-foreground font-medium py-4 px-8 rounded-lg text-lg"
            onClick={() => setLocation("/recommendations")}
            data-testid="button-view-recommendations"
          >
            View Your AI Recommendations
            <TrendingUp className="ml-2 h-5 w-5" />
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
