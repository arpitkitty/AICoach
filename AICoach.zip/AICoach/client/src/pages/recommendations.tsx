import { useEffect } from "react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { CalendarCheck, Dumbbell, GraduationCap, Lightbulb, Brain, Heart, Edit, Play } from "lucide-react";
import { FullPageLoading } from "@/components/ui/loading";
import { useQuery } from "@tanstack/react-query";
import { getRecommendations } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import type { AIRecommendation } from "@shared/schema";

const categoryIcons = {
  daily_habits: CalendarCheck,
  fitness: Dumbbell,
  learning: GraduationCap,
  wellness: Heart,
};

const categoryColors = {
  daily_habits: "text-primary",
  fitness: "text-secondary",
  learning: "text-accent",
  wellness: "text-green-400",
};

const priorityColors = {
  high: "bg-red-500/20 text-red-400 border-red-500/30",
  medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
  low: "bg-green-500/20 text-green-400 border-green-500/30",
};

export default function Recommendations() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const userId = localStorage.getItem("userId");
  const username = localStorage.getItem("username");

  const { data: recommendations, isLoading, error } = useQuery({
    queryKey: ["/api/recommendations", userId],
    queryFn: () => getRecommendations(userId!),
    enabled: !!userId,
  });

  useEffect(() => {
    if (!userId) {
      setLocation("/");
      return;
    }
    if (error) {
      toast({
        title: "Error",
        description: "Failed to load recommendations. Please try again.",
        variant: "destructive",
      });
    }
  }, [userId, error, setLocation, toast]);

  if (!userId) {
    return null;
  }

  if (isLoading) {
    return <FullPageLoading message="Generating your personalized action plan..." />;
  }

  if (!recommendations || recommendations.length === 0) {
    return <FullPageLoading message="Recommendations not available. Please complete the analysis first." />;
  }

  const groupedRecommendations = recommendations.reduce((acc, rec) => {
    if (!acc[rec.category]) {
      acc[rec.category] = [];
    }
    acc[rec.category].push(rec);
    return acc;
  }, {} as Record<string, AIRecommendation[]>);

  const highPriorityRecommendations = recommendations.filter(rec => rec.priority === 'high');

  return (
    <div className="min-h-screen p-4 pb-24">
      <div className="container mx-auto max-w-5xl">
        {/* Header */}
        <motion.div
          className="text-center mb-12"
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl font-bold gradient-text mb-4">Your AI-Powered Action Plan</h2>
          <p className="text-xl text-muted-foreground">
            Personalized recommendations crafted by AI analysis for {username}
          </p>
        </motion.div>

        {/* Category Grid */}
        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {Object.entries(groupedRecommendations).map(([category, recs], index) => {
            const Icon = categoryIcons[category as keyof typeof categoryIcons] || Lightbulb;
            const colorClass = categoryColors[category as keyof typeof categoryColors] || "text-primary";
            
            return (
              <motion.div
                key={category}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
              >
                <Card className="glass-card h-full">
                  <CardContent className="p-8">
                    <h3 className="text-xl font-semibold mb-6 flex items-center">
                      <Icon className={`mr-3 ${colorClass}`} size={24} />
                      {category.replace('_', ' ').split(' ').map(word => 
                        word.charAt(0).toUpperCase() + word.slice(1)
                      ).join(' ')}
                    </h3>
                    
                    <div className="space-y-4">
                      {recs.map((rec, recIndex) => (
                        <motion.div
                          key={recIndex}
                          className="flex items-start space-x-3 p-3 hover:bg-muted/30 rounded-lg cursor-pointer transition-colors"
                          whileHover={{ scale: 1.02 }}
                          data-testid={`recommendation-${category}-${recIndex}`}
                        >
                          <Checkbox className="mt-1" />
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <p className="font-medium">{rec.title}</p>
                              <Badge 
                                variant="outline" 
                                className={`text-xs ${priorityColors[rec.priority]}`}
                              >
                                {rec.priority}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">{rec.description}</p>
                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <span>{rec.frequency}</span>
                              <span>Impact: {rec.estimatedImpact}/10</span>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* AI Insights Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
        >
          <Card className="glass-card mb-8">
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <Brain className="text-primary mr-3" size={24} />
                AI Insights & Priority Focus
              </h3>
              
              {highPriorityRecommendations.length > 0 && (
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="p-6 bg-gradient-to-br from-primary/10 to-accent/10 border border-primary/20 rounded-xl">
                    <h4 className="font-semibold mb-3 flex items-center">
                      <Brain className="text-primary mr-2" size={20} />
                      Top Priority Recommendations
                    </h4>
                    <div className="space-y-3">
                      {highPriorityRecommendations.slice(0, 2).map((rec, index) => (
                        <div key={index} className="text-sm">
                          <p className="font-medium text-foreground">{rec.title}</p>
                          <p className="text-muted-foreground">{rec.frequency} • {rec.category.replace('_', ' ')}</p>
                        </div>
                      ))}
                    </div>
                    <div className="flex items-center text-sm text-primary mt-4">
                      <Heart className="mr-2 h-4 w-4" />
                      <span>Start with these for maximum impact</span>
                    </div>
                  </div>
                  
                  <div className="p-6 bg-gradient-to-br from-secondary/10 to-primary/10 border border-secondary/20 rounded-xl">
                    <h4 className="font-semibold mb-3 flex items-center">
                      <Lightbulb className="text-secondary mr-2" size={20} />
                      Optimization Insight
                    </h4>
                    <p className="text-muted-foreground mb-4">
                      Based on your profile, implementing these recommendations in the suggested order 
                      will create a compounding effect, with each habit reinforcing the others.
                    </p>
                    <div className="flex items-center text-sm text-secondary">
                      <GraduationCap className="mr-2 h-4 w-4" />
                      <span>Expected {Math.round(recommendations.reduce((sum, rec) => sum + rec.estimatedImpact, 0) / recommendations.length)}% overall improvement</span>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Action Buttons */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 1.0 }}
        >
          <Button
            className="glow-button text-primary-foreground font-medium py-3 px-8 rounded-lg"
            onClick={() => setLocation("/dashboard")}
            data-testid="button-start-plan"
          >
            <Play className="mr-2 h-4 w-4" />
            Start My Plan
          </Button>
          <Button
            variant="outline"
            className="px-8 py-3 border border-border rounded-lg text-foreground hover:bg-muted/30 transition-colors"
            onClick={() => {
              toast({
                title: "Customization Coming Soon",
                description: "Advanced plan customization will be available in the next update.",
              });
            }}
            data-testid="button-customize-plan"
          >
            <Edit className="mr-2 h-4 w-4" />
            Customize Plan
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
