import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { AnimatePresence } from "framer-motion";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navigation } from "@/components/navigation";
import Welcome from "@/pages/welcome";
import Questionnaire from "@/pages/questionnaire";
import Charts from "@/pages/charts";
import Recommendations from "@/pages/recommendations";
import Dashboard from "@/pages/dashboard";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        <Switch>
          <Route path="/" component={Welcome} />
          <Route path="/questionnaire" component={Questionnaire} />
          <Route path="/charts" component={Charts} />
          <Route path="/recommendations" component={Recommendations} />
          <Route path="/dashboard" component={Dashboard} />
          <Route component={NotFound} />
        </Switch>
      </AnimatePresence>
      <Navigation />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-background text-foreground">
          <Router />
          <Toaster />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
