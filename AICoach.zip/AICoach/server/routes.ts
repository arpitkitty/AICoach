import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertUserSchema } from "@shared/schema";
import * as openaiService from "./services/openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // User management routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.json(existingUser);
      }
      
      // Create new user and session
      const user = await storage.createUser(userData);
      await storage.createSession({
        userId: user.id,
        questionnaireData: [],
        currentState: null,
        potentialState: null,
        recommendations: [],
        dailyPlan: [],
        progress: {}
      });
      
      res.json(user);
    } catch (error) {
      res.status(400).json({ error: "Invalid user data" });
    }
  });

  app.get("/api/users/:username", async (req, res) => {
    try {
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });

  // Questionnaire routes
  app.get("/api/questionnaire/initial/:userId", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const questions = await openaiService.generateInitialQuestions(user.username);
      res.json({ questions });
    } catch (error) {
      console.error("Error generating initial questions:", error);
      res.status(500).json({ error: "Failed to generate questions" });
    }
  });

  app.post("/api/questionnaire/answer/:userId", async (req, res) => {
    try {
      const answerSchema = z.object({
        questionId: z.string(),
        question: z.string(),
        answer: z.union([z.string(), z.array(z.string())]),
        type: z.enum(['multiple_choice', 'text', 'checkbox', 'scale'])
      });

      const answerData = answerSchema.parse(req.body);
      const answers = await storage.getQuestionnaireAnswers(req.params.userId);
      answers.push(answerData);
      
      await storage.saveQuestionnaireAnswers(req.params.userId, answers);
      
      // Generate follow-up question if we have fewer than 7 answers
      let followUpQuestion = null;
      if (answers.length < 7) {
        const user = await storage.getUser(req.params.userId);
        if (user) {
          followUpQuestion = await openaiService.generateFollowUpQuestion(answers, user.username);
        }
      }
      
      res.json({ success: true, followUpQuestion });
    } catch (error) {
      console.error("Error saving answer:", error);
      res.status(400).json({ error: "Invalid answer data" });
    }
  });

  app.post("/api/questionnaire/complete/:userId", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const answers = await storage.getQuestionnaireAnswers(req.params.userId);
      if (answers.length === 0) {
        return res.status(400).json({ error: "No answers found" });
      }

      // Analyze personality and potential
      const analysis = await openaiService.analyzePersonalityAndPotential(answers, user.username);
      await storage.saveAnalysis(req.params.userId, analysis.currentState, analysis.potentialState);

      // Generate recommendations
      const recommendations = await openaiService.generateRecommendations(answers, analysis, user.username);
      await storage.saveRecommendations(req.params.userId, recommendations);

      // Generate daily plan
      const dailyPlan = await openaiService.generateDailyPlan(recommendations, user.username);
      await storage.saveDailyPlan(req.params.userId, dailyPlan);

      res.json({ success: true, analysis, recommendations, dailyPlan });
    } catch (error) {
      console.error("Error completing questionnaire:", error);
      res.status(500).json({ error: "Failed to process questionnaire" });
    }
  });

  // Analysis routes
  app.get("/api/analysis/:userId", async (req, res) => {
    try {
      const analysis = await storage.getAnalysis(req.params.userId);
      if (!analysis) {
        return res.status(404).json({ error: "Analysis not found" });
      }
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analysis" });
    }
  });

  // Recommendations routes
  app.get("/api/recommendations/:userId", async (req, res) => {
    try {
      const recommendations = await storage.getRecommendations(req.params.userId);
      res.json({ recommendations });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recommendations" });
    }
  });

  // Daily plan routes
  app.get("/api/daily-plan/:userId", async (req, res) => {
    try {
      const dailyPlan = await storage.getDailyPlan(req.params.userId);
      res.json({ tasks: dailyPlan });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch daily plan" });
    }
  });

  app.patch("/api/daily-plan/:userId/:taskId", async (req, res) => {
    try {
      const { completed } = req.body;
      await storage.updateTaskCompletion(req.params.userId, req.params.taskId, completed);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update task" });
    }
  });

  // AI insights route
  app.get("/api/insights/:userId", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.userId);
      const dailyPlan = await storage.getDailyPlan(req.params.userId);
      const analysis = await storage.getAnalysis(req.params.userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      const insight = await openaiService.generatePersonalizedInsight({
        completedTasks: dailyPlan.filter(task => task.completed).length,
        totalTasks: dailyPlan.length,
        currentState: analysis?.currentState
      }, user.username);

      res.json({ insight });
    } catch (error) {
      console.error("Error generating insight:", error);
      res.status(500).json({ error: "Failed to generate insight" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
