import Groq from "groq-sdk";
import { type QuestionnaireAnswer, type PersonalityAnalysis, type AIRecommendation, type DailyTask } from "@shared/schema";

const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });

export interface GeneratedQuestion {
  id: string;
  question: string;
  type: 'multiple_choice' | 'text' | 'checkbox' | 'scale';
  options?: string[];
  category: 'productivity' | 'fitness' | 'learning' | 'wellness' | 'general';
}

export async function generateInitialQuestions(userName: string): Promise<GeneratedQuestion[]> {
  try {
    const response = await groq.chat.completions.create({
      model: "llama-3.1-70b-versatile",
      messages: [
        {
          role: "system",
          content: "You are an AI personal development coach. Generate personalized questionnaire questions to understand someone's current habits, goals, and challenges. Create diverse question types to gather comprehensive data for analysis. Always respond with valid JSON."
        },
        {
          role: "user",
          content: `Generate 5-7 personalized questions for ${userName} to understand their personal development needs. Include questions about productivity, fitness, learning habits, and wellness. Return ONLY a JSON object with this exact structure: {"questions": [{"id": "unique_id", "question": "question text", "type": "multiple_choice|text|checkbox|scale", "options": ["option1", "option2"] (for multiple_choice/checkbox only), "category": "productivity|fitness|learning|wellness|general"}]}`
        }
      ],
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result.questions || [];
  } catch (error) {
    console.error("Error generating questions:", error);
    throw new Error("Failed to generate questionnaire questions");
  }
}

export async function generateFollowUpQuestion(answers: QuestionnaireAnswer[], userName: string): Promise<GeneratedQuestion | null> {
  try {
    const response = await groq.chat.completions.create({
      model: "llama-3.1-70b-versatile",
      messages: [
        {
          role: "system",
          content: "You are an AI personal development coach. Based on previous answers, generate ONE insightful follow-up question to better understand the person's needs and challenges. Always respond with valid JSON."
        },
        {
          role: "user",
          content: `Based on ${userName}'s previous answers: ${JSON.stringify(answers.slice(-3))}, generate one thoughtful follow-up question to better understand their personal development needs. Return ONLY a JSON object with this exact structure: {"question": {"id": "unique_id", "question": "question text", "type": "multiple_choice|text|checkbox|scale", "options": ["option1", "option2"] (if applicable), "category": "productivity|fitness|learning|wellness|general"}}`
        }
      ],
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result.question || null;
  } catch (error) {
    console.error("Error generating follow-up question:", error);
    return null;
  }
}

export async function analyzePersonalityAndPotential(answers: QuestionnaireAnswer[], userName: string): Promise<{ currentState: PersonalityAnalysis; potentialState: PersonalityAnalysis }> {
  try {
    const response = await groq.chat.completions.create({
      model: "llama-3.1-70b-versatile",
      messages: [
        {
          role: "system",
          content: "You are an AI personal development analyst. Analyze questionnaire responses to assess current performance levels and predict potential improvements across key life areas. Provide realistic scores from 1-10. Always respond with valid JSON."
        },
        {
          role: "user",
          content: `Analyze ${userName}'s questionnaire responses and provide current state and potential state scores (1-10) for: productivity, fitness, learning, wellness, focus, energy. Responses: ${JSON.stringify(answers)}. Return ONLY a JSON object with this exact structure: {"analysis": {"currentState": {"productivity": number, "fitness": number, "learning": number, "wellness": number, "focus": number, "energy": number}, "potentialState": {"productivity": number, "fitness": number, "learning": number, "wellness": number, "focus": number, "energy": number}}}`
        }
      ],
      temperature: 0.5,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result.analysis;
  } catch (error) {
    console.error("Error analyzing personality:", error);
    throw new Error("Failed to analyze personality and potential");
  }
}

export async function generateRecommendations(answers: QuestionnaireAnswer[], analysis: { currentState: PersonalityAnalysis; potentialState: PersonalityAnalysis }, userName: string): Promise<AIRecommendation[]> {
  try {
    const response = await groq.chat.completions.create({
      model: "llama-3.1-70b-versatile",
      messages: [
        {
          role: "system",
          content: "You are an AI personal development coach. Generate specific, actionable recommendations based on questionnaire responses and personality analysis. Focus on daily habits, fitness routines, learning plans, and wellness practices. Always respond with valid JSON."
        },
        {
          role: "user",
          content: `Generate 8-12 personalized recommendations for ${userName} based on their responses: ${JSON.stringify(answers)} and analysis: ${JSON.stringify(analysis)}. Return ONLY a JSON object with this exact structure: {"recommendations": [{"category": "daily_habits|fitness|learning|wellness", "title": "title", "description": "detailed description", "frequency": "daily|weekly|monthly", "priority": "high|medium|low", "estimatedImpact": number(1-10)}]}`
        }
      ],
      temperature: 0.7,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result.recommendations || [];
  } catch (error) {
    console.error("Error generating recommendations:", error);
    throw new Error("Failed to generate recommendations");
  }
}

export async function generateDailyPlan(recommendations: AIRecommendation[], userName: string): Promise<DailyTask[]> {
  try {
    const response = await groq.chat.completions.create({
      model: "llama-3.1-70b-versatile",
      messages: [
        {
          role: "system",
          content: "You are an AI personal development coach. Create a specific daily plan with actionable tasks based on the provided recommendations. Include timing suggestions and priority levels. Always respond with valid JSON."
        },
        {
          role: "user",
          content: `Create a daily action plan for ${userName} based on these recommendations: ${JSON.stringify(recommendations)}. Generate 6-10 specific daily tasks. Return ONLY a JSON object with this exact structure: {"tasks": [{"id": "unique_id", "title": "task title", "description": "detailed description", "category": "category", "scheduledTime": "HH:MM AM/PM (optional)", "completed": false, "priority": "high|medium|low"}]}`
        }
      ],
      temperature: 0.6,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result.tasks || [];
  } catch (error) {
    console.error("Error generating daily plan:", error);
    throw new Error("Failed to generate daily plan");
  }
}

export async function generatePersonalizedInsight(userProgress: any, userName: string): Promise<string> {
  try {
    const response = await groq.chat.completions.create({
      model: "llama-3.1-70b-versatile",
      messages: [
        {
          role: "system",
          content: "You are an AI personal development coach. Provide a personalized, encouraging insight based on the user's progress and patterns. Keep it motivational and actionable."
        },
        {
          role: "user",
          content: `Generate a personalized insight for ${userName} based on their progress: ${JSON.stringify(userProgress)}. Focus on patterns, achievements, and specific suggestions for improvement. Keep it under 100 words and motivational.`
        }
      ],
      temperature: 0.8,
    });

    return response.choices[0].message.content || "Keep up the great work on your personal development journey!";
  } catch (error) {
    console.error("Error generating insight:", error);
    return "Keep up the great work on your personal development journey!";
  }
}
