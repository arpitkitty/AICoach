import { type User, type InsertUser, type Session, type InsertSession, type QuestionnaireAnswer, type PersonalityAnalysis, type AIRecommendation, type DailyTask } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Session methods
  getSession(userId: string): Promise<Session | undefined>;
  createSession(session: InsertSession): Promise<Session>;
  updateSession(userId: string, updates: Partial<InsertSession>): Promise<Session>;
  
  // Questionnaire methods
  saveQuestionnaireAnswers(userId: string, answers: QuestionnaireAnswer[]): Promise<void>;
  getQuestionnaireAnswers(userId: string): Promise<QuestionnaireAnswer[]>;
  
  // Analysis methods
  saveAnalysis(userId: string, currentState: PersonalityAnalysis, potentialState: PersonalityAnalysis): Promise<void>;
  getAnalysis(userId: string): Promise<{ currentState: PersonalityAnalysis; potentialState: PersonalityAnalysis } | undefined>;
  
  // Recommendations methods
  saveRecommendations(userId: string, recommendations: AIRecommendation[]): Promise<void>;
  getRecommendations(userId: string): Promise<AIRecommendation[]>;
  
  // Daily plan methods
  saveDailyPlan(userId: string, tasks: DailyTask[]): Promise<void>;
  getDailyPlan(userId: string): Promise<DailyTask[]>;
  updateTaskCompletion(userId: string, taskId: string, completed: boolean): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private sessions: Map<string, Session>;

  constructor() {
    this.users = new Map();
    this.sessions = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getSession(userId: string): Promise<Session | undefined> {
    return Array.from(this.sessions.values()).find(
      (session) => session.userId === userId,
    );
  }

  async createSession(insertSession: InsertSession): Promise<Session> {
    const id = randomUUID();
    const session: Session = {
      userId: insertSession.userId,
      questionnaireData: insertSession.questionnaireData || [],
      currentState: insertSession.currentState || null,
      potentialState: insertSession.potentialState || null,
      recommendations: insertSession.recommendations || [],
      dailyPlan: insertSession.dailyPlan || [],
      progress: insertSession.progress || {},
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.sessions.set(id, session);
    return session;
  }

  async updateSession(userId: string, updates: Partial<InsertSession>): Promise<Session> {
    const existingSession = await this.getSession(userId);
    if (!existingSession) {
      throw new Error("Session not found");
    }
    
    const updatedSession: Session = {
      ...existingSession,
      ...updates,
      updatedAt: new Date()
    };
    
    this.sessions.set(existingSession.id, updatedSession);
    return updatedSession;
  }

  async saveQuestionnaireAnswers(userId: string, answers: QuestionnaireAnswer[]): Promise<void> {
    await this.updateSession(userId, { questionnaireData: answers });
  }

  async getQuestionnaireAnswers(userId: string): Promise<QuestionnaireAnswer[]> {
    const session = await this.getSession(userId);
    return (session?.questionnaireData as QuestionnaireAnswer[]) || [];
  }

  async saveAnalysis(userId: string, currentState: PersonalityAnalysis, potentialState: PersonalityAnalysis): Promise<void> {
    await this.updateSession(userId, { currentState, potentialState });
  }

  async getAnalysis(userId: string): Promise<{ currentState: PersonalityAnalysis; potentialState: PersonalityAnalysis } | undefined> {
    const session = await this.getSession(userId);
    if (!session?.currentState || !session?.potentialState) {
      return undefined;
    }
    return {
      currentState: session.currentState as PersonalityAnalysis,
      potentialState: session.potentialState as PersonalityAnalysis
    };
  }

  async saveRecommendations(userId: string, recommendations: AIRecommendation[]): Promise<void> {
    await this.updateSession(userId, { recommendations });
  }

  async getRecommendations(userId: string): Promise<AIRecommendation[]> {
    const session = await this.getSession(userId);
    return (session?.recommendations as AIRecommendation[]) || [];
  }

  async saveDailyPlan(userId: string, tasks: DailyTask[]): Promise<void> {
    await this.updateSession(userId, { dailyPlan: tasks });
  }

  async getDailyPlan(userId: string): Promise<DailyTask[]> {
    const session = await this.getSession(userId);
    return (session?.dailyPlan as DailyTask[]) || [];
  }

  async updateTaskCompletion(userId: string, taskId: string, completed: boolean): Promise<void> {
    const tasks = await this.getDailyPlan(userId);
    const updatedTasks = tasks.map(task => 
      task.id === taskId ? { ...task, completed } : task
    );
    await this.saveDailyPlan(userId, updatedTasks);
  }
}

export const storage = new MemStorage();
